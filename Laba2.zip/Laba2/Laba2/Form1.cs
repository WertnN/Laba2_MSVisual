﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;
using System.Windows.Forms;

namespace Laba2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Customer();
        }
        
        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            TypeDescriptor.AddAttributes(listBox1.SelectedItem, new Attribute[] { new ReadOnlyAttribute(true) });
            propertyGrid1.SelectedObject = listBox1.SelectedItem;
            if (listBox1.SelectedIndex != -1)
            {
                propertyGrid1.SelectedObject = listBox1.SelectedItem;
            }
        }
        private void Customer()
        {
            var serializer = new XmlSerializer(typeof(Customers));
            var CustomerFromXml = new List<Customer>();

            using (var reader = new FileStream("Customer.xml", FileMode.Open))
            {
                CustomerFromXml = ((Customers)serializer.Deserialize(reader)).Items;
            }
            
            foreach (var customer in CustomerFromXml)
            {
                listBox1.Items.Add(customer);
                
                

            }
        }

        private void PropertyGrid1_PropertyValueChanged(object s, PropertyValueChangedEventArgs e)
        {
            /*switch (e.ChangedItem.Label)
            {
                case "somePropertyLabel":
                    newBonus.somePropertyValue = e.OldValue.ToString();
                    break;
                default:
                    break;
            }*/
        }
    }
    
}

