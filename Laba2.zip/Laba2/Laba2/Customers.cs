﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Laba2
{
    
 [XmlRoot("customers")]
 public class Customers
{
    [XmlElement("customer")]
    public List<Customer> Items { get; set; }
}
    
}
