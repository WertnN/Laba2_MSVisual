﻿using System.Xml.Serialization;
using System.Xml;

namespace Laba2
{
    public abstract class Parametrs
    {
        public abstract void Show();
    }
    
    public class Customer : Parametrs
    {
        [XmlAttribute("fullname")]
        public string Fullname { get; set; }

        [XmlAttribute("address")]
        public string Address { get; set; }

        [XmlAttribute("city")]
        public string City { get; set; }

        [XmlAttribute("state")]
        public string State { get; set; }

        [XmlAttribute("phone")]
        public string Phone { get; set; }
        public override void Show()
        {
            Fullname = $"{nameof(Fullname)}:{Fullname}; " +
                       $"{nameof(Address)}:{Address}; " +
                       $"{nameof(City)}:{City}; " +
                       $"{nameof(State)}:{State}; " +
                       $"{nameof(Phone)}:{Phone};";


             return;
            
        }
    }

}
